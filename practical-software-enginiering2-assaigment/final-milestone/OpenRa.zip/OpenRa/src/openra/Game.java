/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package openra;

/**
 *
 * @author RunTime Terror
 */
import GameEngine.*;

public class Game {


    public static void main(String[] args) 
    {
        GameGUI tmp = new GameGUI();
        //tmp.setVisible(true);
     
    }
    
}
