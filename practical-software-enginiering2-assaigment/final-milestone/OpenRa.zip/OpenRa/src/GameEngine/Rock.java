
package GameEngine;

import java.awt.Image;

/**
 *
 * @author RunTime Terror
 */
public class Rock extends Sprite{

    public Rock(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
    
    
    
}
