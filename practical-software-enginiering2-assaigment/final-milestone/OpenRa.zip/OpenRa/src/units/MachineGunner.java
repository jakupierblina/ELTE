/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package units;

import java.awt.Image;


/**
 *
 * @author RunTime Terror
 */
public class MachineGunner extends Units {

    public MachineGunner(int positionX, int positionY, int width, int height, Image image) {
        super(positionX, positionY, width, height, image);
    }
    
}

